document.addEventListener("DOMContentLoaded", function() {
    loadTrabajadoresChart();
    loadCamposChart(); // Suponiendo que estas funciones están definidas para cargar gráficas
    loadInsumosChart();
    //loadGastosChart();
    // Función para cargar campos en selects
    function loadCamposToSelect(selectId) {
        fetch('/api/campos-select')
        .then(response => response.json())
        .then(data => {
            const select = document.getElementById(selectId);
            select.innerHTML = '<option value="">Seleccione un Campo</option>'; // Opción predeterminada
            data.forEach(item => {
                let option = new Option('Campo ' + item.idCampo, item.idCampo); // Texto visible, valor del option
                select.add(option);
            });
        })
        .catch(error => console.error('Error al cargar los campos:', error));
    }
    // Función para mostrar la sección basada en el hash de la URL.
    function showSectionFromHash() {
        var hash = window.location.hash.replace('#', '');
        if (hash) {
            showSection(hash);
        }
    }

    showSectionFromHash();
    // Cargar campos en el select de vehículos
    loadCamposToSelect('campo-select');

    // Cargar campos en el select de surcos
    loadCamposToSelect('campo-select-surcos');
});

function loadGastosChart() {
    fetch('/api/gastos')
    .then(response => response.json())
    .then(data => {
        const totalSueldos = parseFloat(data.total_sueldos);
        const totalInsumos = parseFloat(data.total_insumos);
        const totalGastos = totalSueldos + totalInsumos;

        var ctx = document.getElementById('gastosChart').getContext('2d');
        gastosChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Gastos'],
                datasets: [{
                    label: 'Sueldos',
                    data: [totalSueldos],
                    backgroundColor: 'rgba(255, 99, 132, 0.4)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }, {
                    label: 'Insumos',
                    data: [totalInsumos],
                    backgroundColor: 'rgba(54, 162, 235, 0.4)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }, {
                    label: 'Total',
                    data: [totalGastos],
                    backgroundColor: 'rgba(75, 192, 192, 0.4)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error al cargar los datos de gastos:', error));
}


function loadTrabajadoresChart() {
    fetch('/api/trabajadores')
    .then(response => response.json())
    .then(data => {
        const trabajadoresLabels = data.map(item => item.nombre);
        const trabajadoresHorasTrabajadas = data.map(item => item.horasTrabajadas);
        const trabajadoresHorasExtras = data.map(item => item.horasExtras);
        const trabajadoresSueldos = data.map(item => item.sueldo);

        var ctx = document.getElementById('trabajadoresChart').getContext('2d');
        var trabajadoresChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: trabajadoresLabels,
                datasets: [{
                    label: 'Horas Trabajadas',
                    data: trabajadoresHorasTrabajadas,
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }, {
                    label: 'Horas Extras',
                    data: trabajadoresHorasExtras,
                    backgroundColor: 'rgba(255, 99, 132, 0.5)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }, {
                    label: 'Sueldo',
                    data: trabajadoresSueldos,
                    backgroundColor: 'rgba(153, 102, 255, 0.5)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error al cargar los datos de trabajadores:', error));
}


function loadCamposChart() {
    fetch('/api/campos')
    .then(response => response.json())
    .then(data => {
        const camposLabels = data.map(item => "Campo " + item.idCampo);
        const agavesPlantados = data.map(item => item.agavesPlantados);
        const maxAgaves = data.map(item => item.maxAgaves);

        // Datos para la gráfica
        var camposData = {
            labels: camposLabels,
            datasets: [{
                label: 'Agaves Plantados',
                data: agavesPlantados,
                backgroundColor: 'rgba(54, 162, 235, 0.4)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            },
            {
                label: 'Capacidad Máxima',
                data: maxAgaves,
                backgroundColor: 'rgba(255, 206, 86, 0.4)',
                borderColor: 'rgba(255, 206, 86, 1)',
                borderWidth: 1
            }]
        };

        // Inicializar la gráfica
        var ctx = document.getElementById('camposChart').getContext('2d');
        var camposChart = new Chart(ctx, {
            type: 'bar',
            data: camposData,
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
}
function loadInsumosChart() {
    fetch('/api/insumos')
    .then(response => response.json())
    .then(data => {
        const insumoLabels = data.map(item => item.nombre);
        const cantidadTotales = data.map(item => item.cantidadTotal);
        const preciosTotales = data.map(item => item.precioTotal);

        var ctx = document.getElementById('insumosChart').getContext('2d');
        var insumosChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: insumoLabels,
                datasets: [{
                    label: 'Cantidad Total',
                    data: cantidadTotales,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }, {
                    label: 'Precio Total',
                    data: preciosTotales,
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error al cargar los datos de insumos:', error));
}

// La función showSection modificada para utilizar el hash de la URL.
function showSection(sectionId) {
    const sections = ['trabajadores', 'campos', 'insumos', 'gastos']; // Asegúrate de incluir 'gastos' aquí
    sections.forEach(function(id) {
        const element = document.getElementById(id);
        if (element) {
            element.style.display = (id === sectionId) ? 'block' : 'none';
        }
    });

    // Si se muestra la sección de gastos, carga la gráfica de gastos
    if (sectionId === 'gastos') {
        loadGastosChart();
    }
}



document.getElementById('tu-boton-vehiculos').addEventListener('click', function() {
    showSection('vehiculos'); // Asegúrate de que este sea el ID correcto para la sección vehículos
    fetch('/api/campos-select')
        .then(response => response.json())
        .then(data => {
            const select = document.getElementById('enCampo'); // Asegúrate de que este sea el ID correcto del elemento select en tu HTML
            select.innerHTML = '<option value="">Seleccione un Campo</option>'; // Asegúrate de mantener la opción predeterminada
            data.forEach(campo => {
                const option = document.createElement('option');
                option.value = campo.idCampo;
                option.textContent = 'Campo ' + campo.idCampo;
                select.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error al obtener los campos:', error);
        });
});
document.getElementById2('tu-boton-vehiculos').addEventListener('click', function() {
    showSection('vehiculos'); // Asegúrate de que este sea el ID correcto para la sección vehículos
    fetch('/api/campos-select')
        .then(response => response.json())
        .then(data => {
            const select = document.getElementById('enCampo'); // Asegúrate de que este sea el ID correcto del elemento select en tu HTML
            select.innerHTML = '<option value="">Seleccione un Campo</option>'; // Asegúrate de mantener la opción predeterminada
            data.forEach(campo => {
                const option = document.createElement('option');
                option.value = campo.idCampo;
                option.textContent = 'Campo ' + campo.idCampo;
                select.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error al obtener los campos:', error);
        });
});


document.addEventListener("DOMContentLoaded", function() {
    // Escucha el evento de clic en el botón "Agave Precio"
    document.getElementById('btn-precio-agave').addEventListener('click', function(e) {
        e.preventDefault(); // Previene la navegación a una nueva página
        // Llama a la función para obtener y almacenar el precio
        obtenerYMostrarPrecioAgave();
    });
});

function obtenerYMostrarPrecioAgave() {
    // Primero, dispara la función que almacena el precio en la base de datos
    fetch('/almacenar_precio_agve')
    .then(response => response.json())
    .then(data => {
        if (data.mensaje) {
            // Si el precio se almacena correctamente, obtén el último precio y muéstralo
            fetch('/obtener_ultimo_precio_agve')
            .then(response => response.json())
            .then(data => {
                if (!data.error) {
                    // Actualiza el contenido en la página con el nuevo precio
                    document.getElementById('precio-agve').innerHTML =
                        'Último precio del AGVE: $' + data.precio.toFixed(2) +
                        ' (Actualizado en: ' + data.fecha + ')';
                } else {
                    document.getElementById('precio-agve').innerHTML = data.error;
                }
            });
        } else {
            document.getElementById('precio-agve').innerHTML = 'Error al almacenar el precio del AGVE.';
        }
    });
}
